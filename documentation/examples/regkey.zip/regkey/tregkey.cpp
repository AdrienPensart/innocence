// tregkey.cpp - test RegKey class
#define _UNICODE
//#undef _MBCS

#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif // _DEBUG

#include <cassert>
#include <cstring>
#include <iostream>
#include <sstream>
#include <map>
#include "win/regkey.h"

#ifdef _UNICODE
#define tcout wcout
#else
#define tcout cout
#endif

using namespace std;

void
test_reg_value(void)
{
	RegValue v0;
	assert (v0.Type == REG_NONE);
	assert (v0.Size() == 0);

	DWORD dw(123);
	RegValue v1(dw);
	assert (v1.Type == REG_DWORD);
	assert (v1.Size() == sizeof(DWORD));
	assert (0 == memcmp(&dw, &v1.Data[0], sizeof(DWORD)));
	assert (v0 != v1);
	assert (v0 < RegValue(dw + 1));

	DWORD dw2 = v1;
	assert (dw2 == dw);
//	assert (dw2 == v1);
	assert (v1 == dw2);
	dw = 234;
	v1 = dw;
	assert (v1 == dw);
	assert (v1 != v0);
	

	QWORD qw(456);
	RegValue qwv(qw);
	assert (qwv.Type == REG_QWORD);
	assert (qwv.Size() == sizeof(QWORD));
	assert (0 == memcmp(&qw, &qwv.Data[0], sizeof(QWORD)));

	RegValue szv(_T("Hi"));
	size_t sz = sizeof(_T("Hi"));
	assert (szv.Type == REG_SZ);
	assert (szv.Size() == sz);
	assert (0 == memcmp(_T("Hi\0"), &szv.Data[0], sz));
	assert (szv == _T("Hi"));
	szv = _T("Bye");
	assert (szv == _T("Bye"));

	RegValue v;
	v = szv;
	assert (v.Type == REG_SZ);
	assert (v.Size() == sizeof(TCHAR)*4);
	assert (0 == memcmp(_T("Bye\0"), &v.Data[0], 4));

	const TCHAR* av[] = { _T("An"), _T("array"), _T("of strings") };
	RegValue avv(sizeof(av)/sizeof(*av), av);
	assert (avv.Type == REG_MULTI_SZ);

	TCHAR pav[] = _T("An\0array\0of strings\0");

	assert (avv.Size() == sizeof(pav));
	assert (0 == memcmp(&avv.Data[0], pav, sizeof(pav)));
	assert (0 == _tcscmp(avv.at(0), av[0]));
	assert (0 == _tcscmp(avv.at(1), av[1]));
	assert (0 == _tcscmp(avv.at(2), av[2]));

	RegValue vex(_T("%foo%\\bar"), true);
	assert (vex.Type == REG_EXPAND_SZ);
}

void
test_reg_key(void)
{
	RegKey k(HKEY_LOCAL_MACHINE);
	k.Open(_T("SOFTWARE\\Microsoft\\Office"));
	if (!k) {
		_tperror(_T("can't open"));

		exit (1);
	}

	RegKeyForwardIterator i(k), ke;
	while (i != ke) {
		tcout << *i << _T(": ");
		// print subkeys
		RegKey l(HKEY_LOCAL_MACHINE); 
		Tstring ts(k.Path());
		ts += _T("\\");
		ts += *i;
		l.Open(ts.c_str());
		copy (RegKeyForwardIterator(l), RegKeyForwardIterator(), 
			ostream_iterator<const TCHAR*, TCHAR>(tcout, _T(" ")));
		tcout << "\n";
		++i;
	}
	k.Close();

	// open or create key HKCU\TEMP
	RegKey r(HKEY_CURRENT_USER);
	if (ERROR_SUCCESS != r.Open(_T("TEMP")))
		r.Create(_T("TEMP"));

	// write some values
	r[_T("Foo")] = _T("bar");
	assert (r[_T("Foo")] == _T("bar"));

	r[_T("Blah")] = (DWORD)123;
	assert (r[_T("Blah")] == (DWORD)123);

	const TCHAR* s[] = {_T("A"), _T("few"), _T("strings")};
	r[_T("Baz")] = RegValue(sizeof(s)/sizeof(*s), s);
	RegValue baz(r[_T("Baz")]);
	assert (Tstring(baz.at(0)) == s[0]);
	assert (Tstring(baz.at(1)) == s[1]);
	assert (Tstring(baz.at(2)) == s[2]);

	// RegKey can be used as HKEY.
	RegFlushKey(r);

	r.Close();

	// read values back in
	r.Open(_T("TEMP"));
	assert (r[_T("Foo")] == _T("bar"));
	assert (r[_T("Blah")] == (DWORD)123);
	assert (r[_T("Baz")] == baz);
	RegValue v = r[_T("BadName")];
	assert (v.Type == REG_NONE);

	TCHAR buf[10];
	_tcsncpy(buf, r[_T("Foo")].QueryValue(), 10);
	assert (0 == _tcscmp(buf, _T("bar")));
//	DWORD dw = r["Blah"];
//	assert (dw == 123);

	// iterate over name-value pairs
	map<Tstring,RegValue> val;
	RegValueForwardIterator vi(r), ve;
	while (vi != ve) {
		val[(*vi).first] = (*vi).second;
		++vi;
	}
	assert (val.size() == 3);
	assert (val[_T("Foo")] == r[_T("Foo")]);
	assert (val[_T("Blah")] == r[_T("Blah")]);
	assert (val[_T("Baz")] == baz);
	r.Close();

	RegDeleteKey(HKEY_CURRENT_USER, _T("TEMP"));
}

void
test_reg_delete(void)
{
	RegKey k(HKEY_CURRENT_USER);

	if (ERROR_SUCCESS != k.Open(_T("A")))
		k.Create(_T("A"));
	k[_T("Aname")] = _T("Avalue");
	k.Create(_T("A\\Ba"));
	k[_T("Aname")] = _T("Avalue");
	k.Create(_T("A\\Bb"));
	k[_T("Aname")] = _T("Avalue");
	k.Create(_T("A\\Bb\\Ca"));
	k[_T("Aname")] = _T("Avalue");
	k.Create(_T("A\\Bc"));
	k[_T("Aname")] = _T("Avalue");

	k.Close();
	k.Open(_T("A"));
	k.Delete();

	assert (ERROR_SUCCESS != k.Open(_T("A")));

	k.Create(_T("A"));
	assert (k.isLeaf());
	assert (k.isEmpty());

	k.Create(_T("A\\B"));
	assert (k.isLeaf());
	assert (k.isEmpty());
	k[_T("Name")] = _T("Value");
	RegFlushKey(k);
	assert (k.isLeaf());
	assert (!k.isEmpty());

	k.Close();

	k.Open(_T("A"));
	assert (!k.isLeaf());
	assert (k.isEmpty());

	k.Delete();
}

void
test_perfmon(void)
{
	RegKey p(HKEY_PERFORMANCE_DATA);
	RegValueForwardIterator i(p), e;
	for (; i != e; ++i) {
		const TCHAR* n = (*i).first;
		RegValue v = (*i).second;
		if (v.Type == REG_SZ)
			tcout << n << _T(": ") << v.operator const TCHAR*() << endl;
	}
}

#ifdef _UNICODE
void
test_unicode(void)
{
	TCHAR* loc  = _wsetlocale(LC_ALL, L"Chinese");
	assert (loc != 0);

	TCHAR yiersan[] = _T("\u4e00\u4e8c\u4e09");

	RegDeleteKey(HKEY_CURRENT_USER, _T("OneTwoThree"));	
	RegKey k(HKEY_CURRENT_USER);
	k.Create(_T("OneTwoThree"));
	k[_T("Chinese")] = yiersan;
	k.Close();
}
#endif

int
_tmain()
{
#ifdef _DEBUG
	_CrtSetDbgFlag (_CRTDBG_ALLOC_MEM_DF); {
#endif

	test_reg_value();
	test_reg_key();
	test_reg_delete();
	test_perfmon();
#ifdef _UNICODE
	test_unicode();
#endif
	
#ifdef _DEBUG
	} _CrtDumpMemoryLeaks();
#endif

	return 0;
}